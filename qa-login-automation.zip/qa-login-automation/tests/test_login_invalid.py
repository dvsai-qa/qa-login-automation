from pages.login_page import LoginPage

def test_login_invalid(driver):
    login = LoginPage(driver)
    login.login("wrong", "wrong")
    assert "Invalid credentials" in driver.page_source
