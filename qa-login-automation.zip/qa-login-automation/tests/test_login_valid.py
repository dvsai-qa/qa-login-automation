from pages.login_page import LoginPage

def test_login_valid(driver):
    login = LoginPage(driver)
    login.login("admin", "password123")
    assert "Dashboard" in driver.title
