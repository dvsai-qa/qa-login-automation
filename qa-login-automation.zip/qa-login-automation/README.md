# QA Login Automation (Python + Selenium)

This project automates login functionality tests using PyTest and Selenium WebDriver with the Page Object Model.

## Features
- Valid and invalid login tests
- Screenshot capture
- HTML report generation

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run tests: `pytest`
3. View the `report.html` for results.
