# Placeholder for future configuration settings
base_url = "https://example.com/login"
