#!/bin/bash
pytest --html=report.html --self-contained-html
